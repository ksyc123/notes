# SSM阶段考试卷

## 需求

​        后台系统用户管理，几乎是所有项目都必须要有的功能。要求使用SpringBoot+MyBatis实现，其维护的功能包括：添加新用户、修改用户、禁用|启用用户、删除用户及用户分页查询展示。

此次考试要求完成以下功能：

1. 用户登陆后才能进行用户管理页面
2. 完成用户的CRUD
3. 完成用户的禁用与恢复功能

## 数据库表结构

 ![image-20210808013027942](img/image-20210808013027942.png)

| 字段名   | 类型        | 说明                    |
| -------- | ----------- | ----------------------- |
| id       | int         | 主键自增                |
| username | varchar(20) | 登陆用户名              |
| password | varchar(32) | 登陆密码  默认"123456"  |
| nickname | varchar(20) | 登陆后显示的昵称        |
| gender   | char(1)     | 用户性别                |
| email    | varchar(60) | 邮件地址                |
| state    | tinyint     | 用户状态：0=禁用;1=正常 |
| created  | datetime    | 创建时间                |
| updated  | datetime    | 最后修改时间            |

sql如下：

```sql
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `gender` char(1) NOT NULL,
  `email` varchar(60) NOT NULL,
  `state` tinyint(4) NOT NULL,
  `created` datetime not NULL,
  `updated` datetime not NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci;

-- ----------------------------
-- Records of t_admin   测试用户:admin 密码：123456
-- ----------------------------
INSERT INTO `t_admin` VALUES (null, 'admin', '123456', 'admin', '1', 'admin@admin.com', 1, now(), now());
```

## 实现要求

导入项目模板，需要根据需求修改配置文件和添加相应代码。【注意：部分代码已提供，需要完善 需要完善的代码有 "// 请在此处填写代码" 提示】

采用restful风格的方式，实现需求

前后端都用json来交互数据

| 前端axios请求方式 | 后台controller接收请求方法 |
| ----------------- | -------------------------- |
| axios.get         | @GetMapping                |
| axios.put         | @PutMapping                |
| axios.post        | @PostMapping               |
| axios.delete      | @DeleteMapping             |



### 问题1 - 完成登录操作（15）

1. 编写 Controller 接受表单数据

2. User 实体正常封装数据

3. 编写 Service 逻辑

4. 编写 Dao 逻辑

5. 映射关系编写

6. 登录失败提示错误信息，登录成功后跳转到用户管理页面

  

### 问题2 - 必须登录才能进入用户管理页面（20）

1. 创建LoginCheckFilter过滤器
2. 编写过滤器类中的 doFilter 方法，如果完成登录正常访问，没有完成登录，跳转到登录页面
3. 在启动类上打上@ServletComponentScan注解

### 问题3 - 实现用户管理的CRUD（65）