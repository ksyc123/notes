package com.itheima.bean;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PageParam {
 private    Integer pageCurrent;
 private    Integer pageSize;
 private   Admin admin;

}
