package com.itheima.service;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.itheima.bean.Admin;
import com.baomidou.mybatisplus.extension.service.IService;
import com.itheima.bean.PageParam;
import com.itheima.bean.Result;


/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhongji
 * @since 2022-09-12
 */
public interface IAdminService extends IService<Admin> {
    public Result selectAll();

    public Result add(PageParam pageParam);

    public Result delete(PageParam pageParam);

    public Result update(PageParam pageParam);

    public Result selectOne(PageParam pageParam);
}

