package com.itheima.dao;

import com.itheima.bean.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itheima.bean.Result;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zhongji
 * @since 2022-09-12
 */

public interface AdminDao extends BaseMapper<Admin> {


}
