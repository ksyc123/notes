package com.itheima.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.itheima.bean.Admin;
import com.itheima.bean.PageParam;
import com.itheima.bean.Result;
import com.itheima.dao.AdminDao;
import com.itheima.service.IAdminService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zhongji
 * @since 2022-09-12
 */
@Service
public class AdminServiceImpl extends ServiceImpl<AdminDao, Admin> implements IAdminService {
    @Autowired
    private AdminDao adminDao;


    public Result selectAll(){
        List<Admin> admins = adminDao.selectList(null);
         return admins==null?new Result(false,"查询失败"):new Result(true,"查询成功",admins);

    }

    public Result add(PageParam pageParam){
        Admin admin = pageParam.getAdmin();
        LambdaQueryWrapper<Admin> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Admin::getUsername,admin.getUsername());
        Admin flag = adminDao.selectOne(lqw);
        if(flag==null){
            int insert = adminDao.insert(admin);
            if(insert!=0){return new Result(true,"插入成功");}
            else{return new Result(false,"插入失败");}
        }else {return new Result(false,"有重复的用户名");}
    }

    public Result delete(PageParam pageParam){
        Admin admin = pageParam.getAdmin();
        LambdaQueryWrapper<Admin> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Admin::getId,admin.getId());
        int delete = adminDao.delete(lqw);
        if(delete!=0){return new Result(true,"删除成功");}
        else {return new Result(false,"删除失败");}
    }

    public Result update(PageParam pageParam){
        Admin admin = pageParam.getAdmin();
        int i = adminDao.updateById(admin);
        if(i!=0){return new Result(true,"修改成功");}
        else{return new Result(false,"修改失败");}
    }

    public Result selectOne(PageParam pageParam){
        Admin admin = pageParam.getAdmin();
        LambdaQueryWrapper<Admin> lqw = new LambdaQueryWrapper<>();
        lqw.eq(Admin::getUsername,admin.getUsername()).eq(Admin::getPassword,admin.getPassword());
        Admin admin1 = adminDao.selectOne(lqw);
        return admin1==null?new Result(false,"登陆失败"):new Result(true,"登陆成功");
    }
}
