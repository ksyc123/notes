package com.itheima.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 分页数据封装工具类
 * 泛型类
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PageBean<T> implements Serializable {
    private List<T> list;   //当前页数据
    private Long total;         //总条数
}
