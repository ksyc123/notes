package com.itheima.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.itheima.bean.Admin;
import com.itheima.bean.PageParam;
import com.itheima.bean.Result;
import com.itheima.service.IAdminService;
import com.itheima.service.impl.AdminServiceImpl;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zhongji
 * @since 2022-09-12
 */

@RestController
@RequestMapping("/admin")
public class AdminController {

    private IAdminService adminService;

    @GetMapping
    public Result selectAll(){
       return adminService.selectAll();
    }

    @PutMapping
    public Result add(@RequestBody PageParam pageParam){
       return adminService.add(pageParam);
    }

    @PostMapping
    public Result delete(@RequestBody PageParam pageParam){
      return adminService.delete(pageParam);
    }

    @DeleteMapping
    public Result update(@RequestBody PageParam pageParam){
      return adminService.update(pageParam);
    }


    @PostMapping("/login")
    public Result selectOne(@RequestBody PageParam pageParam){

        return adminService.selectOne(pageParam);
    }

}

