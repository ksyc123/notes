package com.itheima.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class LoginFilter implements Filter {
    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        //0.强转两个对象
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        //请在此处填写代码




        //2.2：没有登录：跳转到登录页面index.html
        //如果当前请求不是ajax请求 就直接跳转到登录页面
        String XRequested =req.getHeader("X-Requested-With");
        if(!"XMLHttpRequest".equals(XRequested)){
            resp.sendRedirect("/index.html");
            return;
        }
        //如果当前请求是ajax请求 使用401状态码提示需要登录认证 跳转到登录页面
        resp.setStatus(401);
    }

    @Override
    public void init(FilterConfig config) throws ServletException {

    }

}