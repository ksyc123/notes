package com.itheima.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 实体类
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Admin {
    private Integer id; // 主键，自动增长
    private String username; // 登陆用户名
    private String password; // 登陆密码
    private String nickname; // 登陆后显示的名称
    private String gender; // 用户性别
    private String email; // 邮件地址
    private Integer state; // 用户状态：0：失效，1：正常
    private Date created; // 创建时间
    private Date updated; // 最后修改时间

}
