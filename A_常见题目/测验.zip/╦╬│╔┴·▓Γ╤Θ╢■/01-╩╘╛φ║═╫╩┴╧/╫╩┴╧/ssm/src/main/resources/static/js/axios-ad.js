axios.interceptors.response.use((response) => {
    return response;

}, function (error) {
    if (401 === error.response.status) {
        alert("登陆超时，请重新登陆")
        window.location = '/index.html';
    } else{
        return Promise.reject(error);
    }
});
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';