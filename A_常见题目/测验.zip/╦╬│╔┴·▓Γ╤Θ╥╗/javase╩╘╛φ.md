## 1.选择题(共20题,每题2分,总分:40分)

1.【单选题】

以下关于toString（）方法、equals（）方法说法正确的是？（ ）

|      | A： 重写Object类的toString（）方法是为了方便打印对象的地址值。 |      |
| ---- | ------------------------------------------------------------ | ---- |
|      | B： 重写Object类的equals（）方法是为了比较对象的地址值。     |      |
|      | C： 未重写Object类的equals()方法默认是比较对象中的属性值。   |      |
|      | D： 重写Object类的toString()方法是方便打印对象中的属性值 。  |      |

2.【单选题】

以下代码可以正确获取当前系统的时间并格式化输出的是哪项？（ ）

A:

```java
SimpleDateFormat f = new SimpleDateFormat("yyyy年MM月dd日");
Date d  = f.parse("2019年04月12日");
System.out.println(d);
```

B:

```java
SimpleDateFormat f = new SimpleDateFormat("yyyy/MM/dd");
String s  = f.parse(new Date());
System.out.println(s);
```

C:

```java
SimpleDateFormat f = new SimpleDateFormat("yyyy.MM.dd");
Date d = f.format(new Date());
System.out.println(d);
```

D:

```java
SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
String s = f.format(new Date());
System.out.println(s);
```

 3.【单选题】

以下关于Iterator迭代器的说法不正确的是？（ ）

|      | A： 在调用Iterator的next方法之前，迭代器的索引位于第一个元素之前，不指向任何元素。 |      |
| ---- | ------------------------------------------------------------ | ---- |
|      | B： 当第一次调用迭代器的 next方法后，迭代器的索引会向后移动一位，指向第一个元素并将该元素返回。 |      |
|      | C： next() :返回迭代的下一个元素。                           |      |
|      | D： hasNext() :如果仍有元素可以迭代，则返回 false。          |      |

4.【单选题】

以下代码片段哪项是使用的foreach遍历？（ ）

A:

```java
public static void main(String[] args){
   Collection<String> c = new ArrayList<>();
   c.add("博学谷");
   c.add("酷丁鱼");
   c.add("传智汇");
   Iterator<String> it = c.iterator();
   while (it.hasNext()){
      String s = it.next();
      System.out.println(s);
   }
}
```

B:

```java
public static void main(String[] args){
   Collection<String> c = new ArrayList<>();
   c.add("博学谷");
   c.add("酷丁鱼");
   c.add("传智汇");
   for (String s : c) {
      System.out.println(s);
   }
}
```

C:

```java
public static void main(String[] args){
   ArrayList<String> list = new ArrayList<>();
   list.add("博学谷");
   list.add("酷丁鱼");
   list.add("传智汇");
   for (int i = 0; i < list.size(); i++) {
      System.out.println(list.get(i));
   }
}
```

D:

```java
public static void main(String[] args){
   ArrayList<String> list = new ArrayList<>();
   list.add("博学谷");
   list.add("酷丁鱼");
   list.add("传智汇");
   for (int i = list.size() - 1; i >= 0; i--) {
      System.out.println(list.get(i));
   }
}
```

 5.【单选题】

以下关于List集合说法不正确的是？（）

|      | A： List集合是一个带有索引的集合，通过索引就可以精确的操作集合中的元素。 |      |
| ---- | ------------------------------------------------------------ | ---- |
|      | B： List集合是元素有序，可以重复。                           |      |
|      | C： List集合中ArrayList的特点是：查询快，增删慢 ，LinkedList的特点是：查询慢，增删快，因此查询多用ArrayList,增删多用LinkedList。 |      |
|      | D： List集合是根据对象的哈希值来确定元素在集合中的存储位置，因此具有良好的存取和查找性能。 |      |

6.【单选题】

以下哪项方法不是Collections工具类方法？（）

|      | A： addAll(Collection<? super T> c, T... elements) |      |
| ---- | -------------------------------------------------- | ---- |
|      | B： shuffle(List<?> list)                          |      |
|      | C： get(int index)                                 |      |
|      | D： sort(List<T> list)                             |      |

7.【单选题】

以下关于Comparator比较器的代码片段按照首字母降序排序的是？ （）

 

A:

```java
public static void main(String[] args){
   ArrayList<String> list = new ArrayList<>() ;
   list.add("abc");
   list.add("zcd");
   list.add("eyz");
   Collections.sort(list, new Comparator<String>() {
      @Override
      public int compare(String o1, String o2) {
         return o1-o2;
      }
   });
}
```

B:

```java
public static void main(String[] args){
    ArrayList<String> list = new ArrayList<>() ;
    list.add("abc");
    list.add("zcd");
    list.add("eyz");
    Collections.sort(list, new Comparator<String>() {
    	@Override
        public int compare(String o1, String o2) {
        	return o1.charAt(0)-o2.charAt(0);
        }
   });
}
```

C:

```java
public static void main(String[] args){
   ArrayList<String> list = new ArrayList<>() ;
   list.add("abc");
   list.add("zcd");
   list.add("eyz");
   Collections.sort(list, new Comparator<String>() {
      @Override
      public int compare(String o1, String o2) {
         return o2-o1;
      }
   });
}
```

D:

```java
public static void main(String[] args){
   ArrayList<String> list = new ArrayList<>() ;
   list.add("abc");
   list.add("zcd");
   list.add("eyz");
   Collections.sort(list, new Comparator<String>() {
      @Override
      public int compare(String o1, String o2) {
         return o2.charAt(0)-o1.charAt(0);
      }
   });
}
```

 8.【单选题】

以下关于Map集合说法不正确的是？（）

|      | A： Map 中的集合可以包含重复的键，重复的值。                 |      |
| ---- | ------------------------------------------------------------ | ---- |
|      | B： Map 中的集合，每个键只能对应一个值。                     |      |
|      | C： 每个元素由键与值两部分组成，通过键可以找对所对应的值。   |      |
|      | D： 遍历Map集合的方式有两种，通过keyset()获得所有键，再通过键找值；通过entrySet()获取到Map集合中所有的键值对对象的集合，再通过getKey()、getValue()获取键和值。 |      |

9.【单选题】

以下代码片段执行后，控制台的输出结果为？（ ）

```java
public static void main(String[] args){
   Map<Integer,String> map = new HashMap<>();
   map.put(1,"Android");
   map.put(2,"PHP");
   map.put(3,"Python");
   map.put(1,"Java");
   map.remove(2);
   System.out.println(map.get(1));
   System.out.println(map.get(2));
   System.out.println(map.get(3));
}
```

|      | A： Android null Python |      |
| ---- | ----------------------- | ---- |
|      | B： Java Python         |      |
|      | C： Android Python      |      |
|      | D： Java null Python    |      |

10.【单选题】

以下能够获取到当前的毫秒时刻值的是？ （）

|      | A： Calendar.getInstance();            |      |
| ---- | -------------------------------------- | ---- |
|      | B： new Date();                        |      |
|      | C： System.currentTimeMillis() ;       |      |
|      | D： new SimpleDateFormat("yyyy‐MM‐dd") |      |

11.【单选题】

下列选项中哪项不属于运行时异常（ ）

|      | A： IndexOutOfBoundsException |      |
| ---- | ----------------------------- | ---- |
|      | B： NullPointerException      |      |
|      | C： FileNotFoundException     |      |
|      | D： ArithmeticException       |      |

12.【单选题】

以下选项处理异常描述正确的是（ ）

|      | A： try..catch不能处理任何异常。     |      |
| ---- | ------------------------------------ | ---- |
|      | B： throws关键字可以在方法体中使用。 |      |
|      | C： throw关键字运用于方法声明之上。  |      |
|      | D： throw只能抛出异常对象。          |      |

13.【单选题】

以下选项描述多线程创建过程错误的是（ ）

|      | A： Runnable实现类可以直接调用start()启动线程。              |      |
| ---- | ------------------------------------------------------------ | ---- |
|      | B： Thread和Runnable方式创建多线程都需要调用start()启动线程。 |      |
|      | C： 定义Thread类的子类，并重写该类的run()方法。              |      |
|      | D： 定义Runnable接口的实现类，并重写该接口的run()方法。      |      |

14.【单选题】

以下选项描述多线程状态过程正确的是（ ）

|      | A： 新建>可运行>锁阻塞>可运行>被终止。 |      |
| ---- | -------------------------------------- | ---- |
|      | B： 新建>被终止>可运行>锁阻塞。        |      |
|      | C： 新建>计时等待>可运行>被终止。      |      |
|      | D： 新建>无限等待>可运行>锁阻塞。      |      |

15.【单选题】

下列选项中，关于IO流方法描述错误的是（ ）

|      | A： FileReader类的read()方法用来从文件读取一个字符的数据 |      |
| ---- | -------------------------------------------------------- | ---- |
|      | B： FileReader类的read()方法用来从文件读取一个字节的数据 |      |
|      | C： FileWriter类的write()方法可以用来向文件写入字符串    |      |
|      | D： FileWriter类的write()方法可以用来向文件写入单个字符  |      |

16.【单选题】

已知代码如下：

```java
FileWriter fos = new FileWriter("d:/a.txt",true);
fos.write("等一回啊".toCharArray());
fos.write("\r\n"); 
fos.flush();
char[] chars = {'千','年','等','一','回'};
fos.write(chars);
fos.write("我无悔啊");
fos.close();
FileReader fis = new FileReader("d:/a.txt");
int len;
char[] chs = new char[1024];
while((len = fis.read(chs))!=-1){
    System.out.println(new String(chs,0,len));
}
fis.close();
```

已知d:/a.txt文件中原有数据为“千年等一回“，上面代码执行完成后，控制台打印的数据是什么（）

|      | A： 千年等一回等一回啊 千年等一回我无悔啊 |      |
| ---- | ----------------------------------------- | ---- |
|      | B： 等一回啊 千年等一回我无悔啊           |      |
|      | C： 程序运行出现异常                      |      |
|      | D： 控制台没有任何数据                    |      |

17.【单选题】

下列代码的功能是将GBK编码原文本文件，复制为UTF-8的目标文本文件：

```java
InputStreamReader isr = new InputStreamReader(new FileInputStream("d:/a.txt"),"____①______");
OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream("d:/b.txt"),"____②____");
char[] chs = new char[1024];
int len;
while((len = isr.read(chs))!=-1){
    osw.write(chs,0,len);
    System.out.println(new String(chs,0,len));
}
isr.close();
osw.close();
```

横线处应该填写的正确内容是（）

|      | A： ①GBK ②UTF-8   |      |
| ---- | ----------------- | ---- |
|      | B： ①UTF-8 ②GBK   |      |
|      | C： ①GBK ②GBK     |      |
|      | D： ①UTF-8 ②UTF-8 |      |

18.【单选题】

下列关于Lambda表达式描述正确的是（ ）

 

|      | A： 所有可以用匿名内部类传参的方法，都可以用Lambda表达式进行传参。 |      |
| ---- | ------------------------------------------------------------ | ---- |
|      | B： 只有一个方法的接口，才可以使用Lambda表达式               |      |
|      | C： Lambda表达式中可以将形式参数的数据类型省略。             |      |
|      | D： Lambda表达式的大括号和return都可以省略                   |      |

19.【单选题】

@Test注解能够在类的什么位置使用，下列说法正确的是（ ）

|      | A： 在类的方法上使用     |      |
| ---- | ------------------------ | ---- |
|      | B： 在类名上使用         |      |
|      | C： 在类的方法参数上使用 |      |
|      | D： 在类的包名上使用     |      |

20.【单选题】

代码如下：  

```java
Stream<String> stream = Stream.of("张三", "张三", "张三", "赵六","赵六");
List<String> list = stream.skip(1).collect(Collectors.toList());
Set<String> set = list.stream().skip(1).collect(Collectors.toSet());
System.out.println(list.size()+"---"+set.size());
```

该程序运行结果是（）

|      | A： 4---2 |      |
| ---- | --------- | ---- |
|      | B： 4---1 |      |
|      | C： 2---2 |      |
|      | D： 1---1 |      |



## 2.多选题(共5题,每题3分,总分:15分)

1.【多选题】

关于递归的描述正确的是（  ）  

|      | A： 是一种直接或间接地调用自身的算法           |      |
| ---- | ---------------------------------------------- | ---- |
|      | B： 使程序变得简洁                             |      |
|      | C： 递归的次数对程序的运行没有任何影响         |      |
|      | D： 递归一定要有条件限定，保证递归能够停止下来 |      |

2.【多选题】

以下关于自动装箱、自动拆箱的概念正确的是？（ ）

|      | A： 装箱：从基本类型转换为对应的包装类对象。 |      |
| ---- | -------------------------------------------- | ---- |
|      | B： 装箱：从包装类对象转换为对应的基本类型。 |      |
|      | C： 拆箱：从基本类型转换为对应的包装类对象。 |      |
|      | D： 拆箱：从包装类对象转换为对应的基本类型。 |      |

3.【多选题】

以下哪项不是Collection的子类？（ ）

|      | A： LinkedHashMap |      |
| ---- | ----------------- | ---- |
|      | B： LinkedHashSet |      |
|      | C： LinkedList    |      |
|      | D： Iterator      |      |

4.【多选题】

网络通讯三要素是 ?（ ）

|      | A： IP地址   |      |
| ---- | ------------ | ---- |
|      | B： 端口号   |      |
|      | C： 网络速度 |      |
|      | D： 通讯协议 |      |

5.【多选题】

下列关于junit单元测试描述正确的是（）

|      | A： @Before 在测试方法运行之前运行的方法注解                |      |
| ---- | ----------------------------------------------------------- | ---- |
|      | B： @Test 测试方法的注解                                    |      |
|      | C： @After 在测试方法运行之后运行的方法注解                 |      |
|      | D： junit单元测试方法执行后结果为红色代表失败，绿色代表成功 |      |

## 3.编程题(共3题,每题15分,总分:45分)

#### 题目一

```java
有如下两类事物，
	普通学生
		属性:姓名，年龄
		行为:吃饭，睡觉，学习
	体育生
		属性:姓名，年龄
		行为:吃饭，睡觉，学习，打篮球
	老师
		属性:姓名，年龄
		行为:吃饭，睡觉，教书
	体育老师
		属性:姓名，年龄
		行为:吃饭，睡觉，教书，打篮球
利用面向对象相关知识，在测试类中，定义一个方法， 展示所有的老师和学生对象属性和行为。
(提示:结合继承，类型判断，多态，接口的知识点完成)。
```

#### 题目二

```java
itheima.txt文件中有一篇英文文章,现需要统计该文件中每一个字符出现的次数.
文件内容:
There are moments in life when you miss someone so much that you just want to pick them from your dreams and hug them for real! Dream what you want to dream;go where you want to go;be what you want to be,because you have only one life and one chance to do all the things you want to do.

　　May you have enough happiness to make you sweet,enough trials to make you strong,enough sorrow to keep you human,enough hope to make you happy? Always put yourself in others’shoes.If you feel that it hurts you,it probably hurts the other person, too.

　　The happiest of people don’t necessarily have the best of everything;they just make the most of everything that comes along their way.Happiness lies for those who cry,those who hurt, those who have searched,and those who have tried,for only they can appreciate the importance of people

　　who have touched their lives.Love begins with a smile,grows with a kiss and ends with a tear.The brightest future will always be based on a forgotten past, you can’t go on well in lifeuntil you let go of your past failures and heartaches.

　　When you were born,you were crying and everyone around you was smiling.Live your life so that when you die,you're the one who is smiling and everyone around you is crying.

　　Please send this message to those people who mean something to you,to those who have touched your life in one way or another,to those who make you smile when you really need it,to those that make you see the brighter side of things when you are really down,to those who you want to let them know that you appreciate their friendship.And if you don’t, don’t worry,nothing bad will happen to you,you will just miss out on the opportunity to brighten someone’s day with this message.
```

#### 题目三

```java
请用“等待唤醒”机制编写一个程序，要求：
第一个线程：遍历1--1000所有的数字，在遍历过程中，如果发现这个数字能同时被
2,3,5,7整除，立即wait()退出等待，让第二个线程进入。
第二个线程：运行后，将一个计数器 + 1，之后再唤醒等待的线程。
主线程中：休息2秒，让两个线程全部执行完毕，打印“计数器”的结果。
注意：第二个线程使用的计数器，要定义在线程外部。
```



