package com.itheima.题目二;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Test {
    public static void main(String[] args) throws IOException {
        char[] c = new char[1024];
        int b=0;
        FileReader fr = new FileReader("就业班测验1\\itheima\\itheima.txt");
        //新建一个Map集合
        HashMap<Character, Integer> hashMap = new HashMap<>();
       while ((b = fr.read(c)) != -1) {

           for (int i = 0; i <b ; i++) {
              if(!hashMap.containsKey(c[i])) {hashMap.put(c[i],1);}
              else{
                int value= hashMap.get(c[i])+1;
                hashMap.put(c[i],value);
              }
           }
       }
//       int sum=0;
//        for (Character s:hashMap.keySet()) {
//            sum+=hashMap.get(s);
//        }
//        System.out.println(sum);用于计算所有值的总数,共计1740个字符
        System.out.println(hashMap);




}}
