package com.itheima.题目一;

public class PysicalStudent extends Student{
    public PysicalStudent() {
    }

    @Override
    public String toString() {
        return "PysicalStudent{" +
                "name='" + getName() + '\'' +
                ", age=" + getAge() +
                '}';
    }

    public PysicalStudent(String name, int age) {
        super(name, age);
    }

    public void playbasketball(){
        System.out.println("体育学生正在打篮球");
    }
}
