package com.itheima.题目三;

public class MyThread1 extends Thread{
//    设置静态变量i保证线程1遍历完后线程2也能停止
static int i=1;
    @Override
    public void run() {
        for (i = 1; i <=1000 ; i++) {
            synchronized (Test.o) {
                if (i % 2 == 0 && i % 3 == 0 && i % 5 == 0 && i % 7 == 0) {
                    Test.flag=true;
                    try {
                        Test.o.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
                else if(i==1000){
                    System.out.println("子线程1遍历完毕!");
                }
            }}
    }
}
