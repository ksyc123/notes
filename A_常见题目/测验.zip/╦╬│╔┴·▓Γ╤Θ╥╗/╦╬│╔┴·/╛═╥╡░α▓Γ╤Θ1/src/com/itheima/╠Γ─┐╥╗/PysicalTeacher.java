package com.itheima.题目一;

public class PysicalTeacher extends Teacher{
    @Override
    public String toString() {
        return "PysicalTeacher{" +
                "name='" + getName() + '\'' +
                ", age=" + getAge() +
                '}';
    }

    public PysicalTeacher() {
    }

    public PysicalTeacher(String name, int age) {
        super(name, age);
    }

    public void playbasketball(){
        System.out.println("体育老师正在打篮球");
    }
}
