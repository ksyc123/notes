package com.itheima.题目三;

public class MyThread2 extends Thread{
    @Override
    public void run() {
        while (true)  {synchronized (Test.o) {
            if (Test.flag) {
                Test.count++;
                Test.o.notify();
                Test.flag = false;
            } else if (MyThread1.i == 1000) {//用线程1的静态变量保证线程2停止
                System.out.println("子线程2执行完毕!");
                return;
            }
        }
        }
        } }

