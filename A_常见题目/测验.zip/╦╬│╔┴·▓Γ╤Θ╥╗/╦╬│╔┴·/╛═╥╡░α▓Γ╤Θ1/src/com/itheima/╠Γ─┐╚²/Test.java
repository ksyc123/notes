package com.itheima.题目三;

public class Test {
    //静态计数器
    static int count=0;
    //标志变量保证每遍历一次能整除的数会计一次数
    static boolean flag=false;
    //锁对象
    static final Object o=new Object();

    public static void main(String[] args) {
        MyThread1 myThread1 = new MyThread1();
        MyThread2 myThread2 = new MyThread2();
        myThread1.start();
        myThread2.start();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(count);//打印结果为4
    }
}
