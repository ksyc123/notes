package com.itheima.题目一;

public interface Action {
    void eat();
  void sleep();
}
