package com.itheima.题目一;

public class Test {
    public static void main(String[] args) {
        //创建对象
        Student zs = new PysicalStudent("张三", 18);
        Teacher lz = new PysicalTeacher("老张", 45);

        //运用多态调用共有行为
        zs.eat();zs.sleep();zs.study();
        lz.eat();lz.sleep();lz.teach();

        //调用特有行为
        PysicalStudent zs1=(PysicalStudent) zs; zs1.playbasketball();
        PysicalTeacher lz1=(PysicalTeacher) lz; lz1.playbasketball();

        //打印属性
        System.out.println(zs);
        System.out.println(lz);
    }}
