package com.itheima.service;

import com.itheima.bean.Book;
import org.springframework.stereotype.Service;

import java.util.List;

public interface BookService {
    //查询所有
    List<Book> selectAll();
    //查询单个根据名称
    Book selectByName(String name);
    //新增一条图书记录
    Integer add(Book book);
    //根据id删除一条图书记录
    Integer delete(Integer id);
    //修改一条图书记录
    Integer update(Book book);
}
