package com.itheima.bean;

public interface Code {
    Integer SELECTALL_OK=20011;
    Integer SELECTBYNAME_OK=20021;
    Integer ADD_OK=20031;
    Integer DELETE_OK=20041;
    Integer UPDATE_OK=20051;

    Integer SELECTALL_ERR=20011;
    Integer SELECTBYNAME_ERR=20021;
    Integer ADD_ERR=20031;
    Integer DELETE_ERR=20041;
    Integer UPDATE_ERR=20051;
}
