package com.itheima.dao;

import com.itheima.bean.Book;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface BookDao {

//查询所有
    @Select("select * from tbl_book ")
    List<Book> selectAll();
//查询单个根据名称
    @Select("select * from tbl_book where name=#{name}")
    Book selectByName(String name);
//新增一条图书记录
    @Insert("insert into tbl_book values(null,#{type},#{name},#{description})")
    Integer add(Book book);
//根据id删除一条图书记录
    @Delete("delete from tbl_book where id=#{id}")
    Integer delete(Integer id);
//修改一条图书记录
    @Update("update tbl_book set type=#{type},name=#{name},description=#{description} where id=#{id}")
    Integer update(Book book);
}
