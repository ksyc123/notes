package com.itheima.service.impl;

import com.itheima.bean.Book;
import com.itheima.dao.BookDao;
import com.itheima.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class BookServiceImpl implements BookService {

//将代理对象注入到dao接口
    @Autowired
    private BookDao bookDao;

//    public BookDao getBookDao() {
//        return bookDao;
//    }
//
//    public void setBookDao(BookDao bookDao) {
//        this.bookDao = bookDao;
//    }


// 查所有
    @Override
    public List<Book> selectAll() {
        System.out.println("sss");
        List<Book> books = bookDao.selectAll();
        System.out.println("s1s1");
        return books;
    }
//查单个
    @Override
    public Book selectByName(String name) {
        Book book = bookDao.selectByName(name);
        return book;
    }
//添加一条记录
    @Override
    public Integer add(Book book) {
        Integer add = bookDao.add(book);
        return add;
    }
//删除一条记录
    @Override
    public Integer delete(Integer id) {
        Integer delete = bookDao.delete(id);
        return delete;
    }
//修改一条
    @Override
    public Integer update(Book book) {
        Integer update = bookDao.update(book);
        return update;
    }
}
