package com.itheima.web;


import com.itheima.bean.Book;
import com.itheima.bean.Code;
import com.itheima.bean.Result;
import com.itheima.service.impl.BookServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookWeb {


    @Autowired
    public BookServiceImpl bookService;

    @GetMapping
    public Result selectAll() {
        System.out.println("000");
        List<Book> books = bookService.selectAll();
        System.out.println("111");
        return books == null ? new Result(Code.SELECTALL_ERR, "查询所有失败") : new Result(books, Code.SELECTALL_OK);
    }

    //查询单个根据名称
    @PostMapping("/{name}")
    public Result selectByName(@PathVariable String name) {
        BookServiceImpl bookService = new BookServiceImpl();
        Book book = bookService.selectByName(name);
        return book == null ? new Result(Code.SELECTBYNAME_ERR, "未查询到任何记录") : new Result(book, Code.SELECTBYNAME_OK);
    }

    //新增一条图书记录
    @PostMapping
    public Result add(@RequestBody Book book) {
        BookServiceImpl bookService = new BookServiceImpl();
        Integer add = bookService.add(book);
        return add == null ? new Result(Code.ADD_ERR, "添加失败") : new Result(Code.ADD_OK, "添加成功");
    }

    //根据id删除一条图书记录
    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        Integer delete = bookService.delete(id);
        return delete == null ? new Result(Code.DELETE_ERR, "删除失败") : new Result(Code.DELETE_OK, "删除成功");
    }

    //修改一条图书记录
    @PutMapping
    public Result update(@RequestBody Book book) {
        BookServiceImpl bookService = new BookServiceImpl();
        Integer update = bookService.update(book);
        return update == null ? new Result(Code.UPDATE_ERR, "修改失败") : new Result(Code.UPDATE_OK, "修改成功");
    }


}
